import { Component } from '@angular/core';

@Component({
  selector: 'app-add-rower',
  templateUrl: './add-rower.component.html',
  styleUrl: './add-rower.component.css'
})
export class AddRowerComponent {
  
}
